const mongoose = require('mongoose');
const nvrSchema = mongoose.Schema({
  description: {type: String, required: true},
  ip: {type: String, required: true},
  channels: {type: Number, required: true},
  port: {type: Number, required: true},
  rtspPort: {type: Number, required: true},
  username: {type: String, required: true},
  password: {type: String, required: true}
})
module.exports = mongoose.model('Nvr', nvrSchema);
