const mongoose = require('mongoose');
const cameraSchema = mongoose.Schema({
  NvrId: {type: String, required: true},
  name: {type: String, required: true},
  channel: {type: Number, required: true},
  ip: {type: String, required: true},
  index: {type: Number, required: true}
})

module.exports = mongoose.model('Camera', cameraSchema);
