var express = require('express');
var cors = require('cors')
var app = express();
const bodyParser = require("body-parser");
const Nvr = require('./models/nvr');
const User = require('./models/user');
const Camera = require('./models/camera');
const Stream = require('node-rtsp-stream')

const mongoose = require('mongoose');
mongoose.connect("mongodb+srv://moria:Lrepx6BhkjdplBbL@cluster0.vy6or.mongodb.net/Project?retryWrites=true&w=majority")
  .then(() => {
    console.log("connection good");
  }).catch((error) => {
    console.log("connection bad");
  });
  
app.use(cors())
app.use(bodyParser.json());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.setHeader("Access-Control-Allow-Methods", "*");
  next();
});
app.get('/api/user', ((req, res) => {
  User.find().then(documents => {
    res.status(200).json(documents);
  })
}));
app.post('/api/nvr', ((req, res) => {
  const nvr = new Nvr({
    description: req.body.description,
    ip: req.body.ip,
    channels: req.body.channels,
    port: req.body.port,
    rtspPort: req.body.rtspPort,
    username: req.body.username,
    password: req.body.password
  });
  nvr.save().then(createdNvr => {
    res.status(201).json({
      nvrId: createdNvr.id
    });
  });
}));
app.get('/api/nvr', ((req, res) => {
  Nvr.find().then(documents => {
    res.status(200).json(documents);
  })
}));
app.delete('/api/nvr/:id', ((req, res) => {
  Nvr.deleteOne({
      _id: req.params.id
    })
    .then(result => {
      console.log(result);
      res.status(200).json({
        message: 'deleted!!'
      });
    })
}))
app.post('/api/camera', ((req, res) => {
  const camera = new Camera({
    name: req.body.name,
    channel: req.body.channel,
    ip: req.body.ip,
    NvrId: req.body.NvrId,
    index: req.body.index
  });
  camera.save().then(createdCamera => {
    res.status(201).json({
      cameraId: createdCamera.id
    });
  });
}));

app.get('/api/camera', ((req, res) => {
  Camera.find().lean().then(documents => {
    res.status(200).json(documents);
  })
}));
app.delete('/api/camera/:id', ((req, res) => {
  Camera.deleteOne({
      _id: req.params.id
    })
    .then(result => {
      console.log(result);
      res.status(200).json({
        message: 'deleted!!'
      });
    })
}))

app.get('/api/users', ((req, res) => {

  const users = [{
      id: 'dsbdj',
      username: 'Moria',
      password: '1234'
    },
    {
      id: 'gfdgfd',
      username: 'Noa',
      password: '1234'
    }
  ]

  res.status(200).json(users);
}));


app.post('/api/preview-camera', ((req, res) => {
  let camera = req.body;
  Nvr.findOne({
    description: camera.NvrId
  }).lean()
  .then(nvr => {
     // init websocket server
    stream = new Stream({
      name: 'name',
      // streamUrl: 'rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov',
      streamUrl: `rtsp://${nvr.username}:${nvr.password}@${nvr.ip}:${nvr.rtspPort}/ISAPI/Streaming/channels/${camera.channel}01`,
      // streamUrl: `rtsp://admin:hvi12345@${nvr.ip}:${nvr.rtspPort}/ISAPI/Streaming/channels/${camera.channel}01`,
      wsPort: 9999,
      ffmpegOptions: { // options ffmpeg flags
        '-stats': '', // an option with no necessary value uses a blank string
        '-r': 30, // options with required values specify the value after the key
        '-c:a': 'mp2',
        '-ar': 44100,
        '-ac': 1
      }
    })
    res.status(200).json({
      success: true
    });
  })
}));


// Change the 404 message modifing the middleware
app.use(function(req, res, next) {
    res.status(404).send("Sorry, that route doesn't exist. Have a nice day :)");
});

// start the server in the port 3000 !
app.listen(3000, function () {
    console.log('Example app listening on port 3000.');
});
