import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NvrPageComponent } from './nvr-page.component';

describe('NvrPageComponent', () => {
  let component: NvrPageComponent;
  let fixture: ComponentFixture<NvrPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NvrPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NvrPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
