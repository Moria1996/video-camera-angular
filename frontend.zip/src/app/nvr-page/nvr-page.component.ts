import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Nvr} from '../models/nvr.model';
import {NvrService} from '../services/nvr.service';
import {Subscription} from 'rxjs';
@Component({
  selector: 'app-nvr-page',
  templateUrl: './nvr-page.component.html',
  styleUrls: ['./nvr-page.component.css']
})
export class NvrPageComponent implements OnInit, OnDestroy {
  nvrList: Nvr[] = [];
  private nvrSub: Subscription;
  constructor(private route: Router, public nvrService: NvrService) {
  }
  ngOnInit(): void {
    this.nvrService.getNvrList();
    this.nvrSub = this.nvrService.getNvrListUpdated()
      .subscribe((nvrList: Nvr[]) => {
        this.nvrList = nvrList;
      });
  }
  // tslint:disable-next-line:typedef
  removeNvr(id: string){
    this.nvrService.deleteNvr(id);
  }

  // tslint:disable-next-line:typedef
  ngOnDestroy() {
    this.nvrSub.unsubscribe();
  }
}
