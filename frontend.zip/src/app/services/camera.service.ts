import { Injectable } from '@angular/core';
import {CameraModel} from '../models/camera.model';
import {Observable, Subject} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CameraService {
  private cameraList: CameraModel[] = [];
  private cameraListUpdated = new Subject<CameraModel[]>();
  constructor(private http: HttpClient) { }
  // tslint:disable-next-line:typedef
  getCameraList(){
    this.http.get<any>('http://localhost:3000/api/camera')
      .pipe(map((cameraData => {
        return cameraData.map(camera => {
          return {
            id: camera._id,
            name: camera.name,
            NvrId: camera.NvrId,
            channel: camera.channel,
            ip: camera.ip,
            index: camera.index
          };
        });
      })))
      .subscribe((cameras => {
        this.cameraList = cameras;
        this.cameraListUpdated.next([...this.cameraList]);
      }));
    return [...this.cameraList];
  }
  // tslint:disable-next-line:typedef
  getCameraListUpdated(){
    return this.cameraListUpdated.asObservable();
  }
  // tslint:disable-next-line:typedef
  addCamera(newCamera: CameraModel){
    this.getCameraList();
    this.http.post<{cameraId: string}>('http://localhost:3000/api/camera', newCamera)
      .subscribe((resData) => {
        const cameraId = resData.cameraId;
        newCamera.id = cameraId;
        this.cameraList.push(newCamera);
        this.cameraListUpdated.next([...this.cameraList]);
      });
  }
  // tslint:disable-next-line:typedef
  deleteCamera(id: string){
    this.http.delete('http://localhost:3000/api/camera/' + id)
      .subscribe(() => {
        const updatedCameraList = this.cameraList.filter(camera => camera.id !== id);
        this.cameraList = updatedCameraList;
        this.cameraListUpdated.next([...this.cameraList]);
      });
  }
  // tslint:disable-next-line:typedef
  previewCamera(data): Observable<any>{
   return this.http.post<any>('http://localhost:3000/api/preview-camera', data)
      .pipe(map((message => {
        return message;
      })));
  }
}
