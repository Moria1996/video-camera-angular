import { Injectable } from '@angular/core';
import {Nvr} from '../models/nvr.model';
import {HttpClient} from '@angular/common/http';
import {Subject} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class NvrService {
  nvrList: Nvr [] = [];
  private nvrListUpdated = new Subject<Nvr[]>();
  constructor(private http: HttpClient) { }
  // tslint:disable-next-line:typedef
  getNvrList(){
    this.http.get<any>('http://localhost:3000/api/nvr')
      .pipe(map((nvrData => {
        return nvrData.map(nvr => {
          return {
            id: nvr._id,
            description: nvr.description,
            channels: nvr.channels,
            ip: nvr.ip,
            port: nvr.port,
            rtspPort: nvr.rtspPort,
            username: nvr.username,
            password: nvr.password
          };
        });
      })))
      .subscribe((changedNvrs) => {
        this.nvrList = changedNvrs;
        this.nvrListUpdated.next([...this.nvrList]);
       });
  }
  // tslint:disable-next-line:typedef
  getNvrListUpdated(){
    return this.nvrListUpdated.asObservable();
  }
  // tslint:disable-next-line:typedef
  addNvr(newNvr: Nvr){
    this.getNvrList();
    this.http.post<{nvrId: string}>('http://localhost:3000/api/nvr/', newNvr)
      .subscribe((resData) => {
        const nvrId = resData.nvrId;
        newNvr.id = nvrId;
        this.nvrList.push(newNvr);
        this.nvrListUpdated.next([...this.nvrList]);
      });
  }
  // tslint:disable-next-line:typedef
  deleteNvr(id: string){
    this.http.delete('http://localhost:3000/api/nvr/' + id)
      .subscribe(() => {
        const updatedNvrList = this.nvrList.filter(nvr => nvr.id !== id);
        this.nvrList = updatedNvrList;
        this.nvrListUpdated.next([...this.nvrList]);
      });
  }
}
