import { TestBed } from '@angular/core/testing';

import { NvrService } from './nvr.service';

describe('NvrService', () => {
  let service: NvrService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NvrService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
