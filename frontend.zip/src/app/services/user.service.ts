import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
import {userModel} from '../models/user.model';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private users: userModel [] = [];
  private usersUpdated = new Subject<userModel[]>();
  constructor(private http: HttpClient) { }
  // tslint:disable-next-line:typedef
  getUsers(){
    this.http.get<userModel[]>('http://localhost:3000/api/users')
      .subscribe((users) => {
        this.users = users;
        this.usersUpdated.next([...this.users]);
      });
  }
  // tslint:disable-next-line:typedef
  getUsersUpdated(){
    return this.usersUpdated.asObservable();
  }
}
