import { Component, OnDestroy, OnInit } from '@angular/core';
import { CameraModel } from '../models/camera.model';
import { CameraService } from '../services/camera.service';
import { Subscription } from 'rxjs';
import { NvrService } from '../services/nvr.service';
declare var JSMpeg: any;

@Component({
  selector: 'app-cameras-page',
  templateUrl: './cameras-page.component.html',
  styleUrls: ['./cameras-page.component.css']
})
export class CamerasPageComponent implements OnInit, OnDestroy {
  cameraList: CameraModel[] = [];
  private player: any;
  private cameraSub: Subscription;
  constructor(public cameraService: CameraService, public nvrService: NvrService) { }

  ngOnInit(): void {
    this.cameraService.getCameraList();
    this.cameraSub = this.cameraService.getCameraListUpdated()
      .subscribe((cameraList: CameraModel[]) => {
        this.cameraList = cameraList;
      });
  }
  // tslint:disable-next-line:typedef
  removeCamera(id: string) {
    this.cameraService.deleteCamera(id);
  }
  // tslint:disable-next-line:typedef
  ngOnDestroy() {
    this.cameraSub.unsubscribe();
  }

  // tslint:disable-next-line:typedef
  previewCamera(camera: CameraModel) {
    this.cameraService.previewCamera(camera)
       .subscribe((resonse: any) => {
         this.player = new JSMpeg.Player('ws://localhost:9999', {
           canvas: document.getElementById('canvas') // Canvas should be a canvas DOM element
         });
       });
  }
}
