import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {userModel} from '../models/user.model';
import {UserService} from '../services/user.service';
import {Subscription} from 'rxjs';

// @ts-ignore
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'login-page',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy{
  private users: userModel[] = [];
  private userSub: Subscription;
  username: string;
  password: string;
  messageToUser = 'Please enter username and password';
  constructor(private route: Router, public userService: UserService){}
  // tslint:disable-next-line:typedef
  ngOnInit() {
    this.userService.getUsers();
    this.userSub = this.userService.getUsersUpdated()
      .subscribe((users: userModel[]) => {
        this.users = users;
      });
  }
  // tslint:disable-next-line:typedef
  loginUser(){
    if (this.users.find(user => user.username === this.username)){
      if (this.users.find(user => user.password === this.password)){
        this.route.navigate(['cameras']);
      }
      else {
        this.messageToUser = 'the password you entered in not correct';
      }
    }
    else {
      this.messageToUser = 'the username you entered in not correct';
    }
  }
  // tslint:disable-next-line:typedef
  ngOnDestroy() {
    this.userSub.unsubscribe();
  }
}
