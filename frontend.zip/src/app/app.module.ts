import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import {LoginComponent} from './login-page/login.component';
import {FormsModule} from '@angular/forms';
import {AppRoutingModule} from './app-routing.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HeadlineComponent } from './headline/headline.component';
import { CamerasPageComponent } from './cameras-page/cameras-page.component';
import { NvrPageComponent } from './nvr-page/nvr-page.component';
import { AddNVRPageComponent } from './add-nvr-page/add-nvr-page.component';
import { AddCameraPageComponent } from './add-camera-page/add-camera-page.component';
import {MatSelectModule} from '@angular/material/select';
import {HttpClientModule} from '@angular/common/http';
import {MatRadioModule} from '@angular/material/radio';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeadlineComponent,
    CamerasPageComponent,
    NvrPageComponent,
    AddNVRPageComponent,
    AddCameraPageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSelectModule,
    HttpClientModule,
    MatRadioModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
