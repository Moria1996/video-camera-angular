import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'headline',
  templateUrl: './headline.component.html',
  styleUrls: ['./headline.component.css']
})
export class HeadlineComponent implements OnInit {
  constructor(private route: Router) {
  }

  ngOnInit(): void {
  }
  // tslint:disable-next-line:typedef
  disconnectUser(){
    this.route.navigate(['']);
  }

}
