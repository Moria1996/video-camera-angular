import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {CameraService} from '../services/camera.service';
import {Nvr} from '../models/nvr.model';
import {NvrService} from '../services/nvr.service';
import {NvrPageComponent} from '../nvr-page/nvr-page.component';
import {CameraModel} from '../models/camera.model';
import {Subscription} from 'rxjs';
// <input type="text" [(ngModel)]="enteredNvrId" name="nvr">
@Component({
  selector: 'app-add-camera-page',
  templateUrl: './add-camera-page.component.html',
  styleUrls: ['./add-camera-page.component.css']
})
export class AddCameraPageComponent implements OnInit, OnDestroy {
  enteredName = '';
  enteredNvrId = '';
  enteredChannel: number;
  enteredIp = '';
  enteredIndex: number;
  messageToUser = '';
  maxForChannels: number;
  channelOptions = [];
  nvrList: Nvr [] = [];
  nvrIds: string [] = [];
  nvrNames: string [] = [];
  private nvrSub: Subscription;
  constructor(private route: Router, public cameraService: CameraService, public nvrService: NvrService) { }

  // tslint:disable-next-line:typedef
  ngOnInit() {
    // @ts-ignore
     this.nvrService.getNvrList();
     this.nvrSub = this.nvrService.getNvrListUpdated()
       .subscribe((nvrList: Nvr []) => {
         this.nvrList = nvrList;
         let i;
         for (i = 0; i < this.nvrList.length; i++){
           this.nvrIds.push(this.nvrList[i].id);
           this.nvrNames.push(this.nvrList[i].description);
         }
       });
  }
  // tslint:disable-next-line:typedef
  updateChannelsOptins(){
    let i;
    // tslint:disable-next-line:no-shadowed-variable
    const nvr: Nvr = this.nvrList.find(nvr => nvr.description === this.enteredNvrId);
    for (i = 1; i <= nvr.channels; i++){
      this.channelOptions[i] = i;
    }
  }
  // tslint:disable-next-line:typedef
  saveCamera(){
    const newCamera: CameraModel = {
      id: '',
      name: this.enteredName,
      NvrId: this.enteredNvrId,
      channel: this.enteredChannel,
      ip: this.enteredIp,
      index: this.enteredIndex
    };
    if (!this.isIpValid(this.enteredIp)){
      this.messageToUser = 'the ip you entered is not valid';
    }
    else {
      if (this.enteredName !== '' && this.enteredNvrId !== '' && this.enteredChannel > 0
        && this.enteredIp !== '' && this.enteredIndex > 0){

        this.cameraService.addCamera(newCamera);
        this.route.navigate(['cameras']);
      }
      else {
        this.messageToUser = 'you need to fill all the boxes';
      }
    }
  }
  // tslint:disable-next-line:typedef
  close(){
    this.route.navigate(['cameras']);
  }
  // tslint:disable-next-line:typedef
  isIpValid(ip: string){
    let i;
    const numbers: string[] = ip.split('.');
    if (numbers.length !== 4){
      return false;
    }
    for (i = 0; i < numbers.length; i++){
      if (+numbers[i] < 0 || +numbers[i] > 256){
        return false;
      }
    }
    return true;
  }
  // tslint:disable-next-line:typedef
  updateChannelsOptions(){
    let i;
    // tslint:disable-next-line:no-shadowed-variable
    const nvr: Nvr = this.nvrList.find(nvr => nvr.description === this.enteredNvrId);
    for (i = 1; i <= nvr.channels; i++){
      this.channelOptions[i] = i;
    }
  }
  // tslint:disable-next-line:typedef
  ngOnDestroy() {
    this.nvrSub.unsubscribe();
  }
}
