import { NgModule} from '@angular/core';
import { Routes, RouterModule} from '@angular/router';
import { LoginComponent} from './login-page/login.component';
import {CamerasPageComponent} from './cameras-page/cameras-page.component';
import {NvrPageComponent} from './nvr-page/nvr-page.component';
import {AddNVRPageComponent} from './add-nvr-page/add-nvr-page.component';
import {AddCameraPageComponent} from './add-camera-page/add-camera-page.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'cameras',
    component: CamerasPageComponent
  },
  {
    path: 'NVR',
    component: NvrPageComponent
  },
  {
    path: 'NVR/addNVR',
    component: AddNVRPageComponent
  },
  {
    path: 'cameras/add-camera',
    component: AddCameraPageComponent
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule{}
