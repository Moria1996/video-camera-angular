import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNVRPageComponent } from './add-nvr-page.component';

describe('AddNVRPageComponent', () => {
  let component: AddNVRPageComponent;
  let fixture: ComponentFixture<AddNVRPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddNVRPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNVRPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
