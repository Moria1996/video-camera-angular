import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Router} from '@angular/router';
import {Nvr} from '../models/nvr.model';
import {NvrService} from '../services/nvr.service';


@Component({
  selector: 'app-add-nvr-page',
  templateUrl: './add-nvr-page.component.html',
  styleUrls: ['./add-nvr-page.component.css']
})
export class AddNVRPageComponent implements OnInit {
  enteredName = '';
  enteredIp = '';
  enteredChannels: number;
  enteredPort: number;
  enteredRtspPort: number;
  enteredUsername: string;
  enteredPassword: string;
  messageToUser = '';
  constructor(private route: Router, public nvrService: NvrService) {
  }
  ngOnInit(): void {
  }
  // tslint:disable-next-line:typedef
  saveNVR(){
    const newNvr: Nvr = {
      id: '',
      description: this.enteredName,
      ip: this.enteredIp,
      channels: this.enteredChannels,
      port: this.enteredPort,
      rtspPort: this.enteredRtspPort,
      username: this.enteredUsername,
      password: this.enteredPassword
    };
    if (!this.isIpValid(this.enteredIp)){
      this.messageToUser = 'the ip you entered is not valid';
    }
    else {
      if (this.enteredName !== '' && this.enteredIp !== '' && this.enteredChannels > 0
        && this.enteredPort > 0 && this.enteredRtspPort > 0 && this.enteredUsername !== ''
      && this.enteredPassword !== '') {
        this.nvrService.addNvr(newNvr);
        this.route.navigate(['NVR']);
      }
      else {
        this.messageToUser = 'you need to fill all the boxes correctly';
      }
    }
  }
  // tslint:disable-next-line:typedef
  close(){
    this.route.navigate(['NVR']);
  }
  // tslint:disable-next-line:typedef
  isIpValid(ip: string){
    let i;
    const numbers: string[] = ip.split('.');
    if (numbers.length !== 4){
      return false;
    }
    for (i = 0; i < numbers.length; i++){
      // @ts-ignore
      if (isNaN(+numbers[i])){
        return false;
      }
      if (+numbers[i] < 0 || +numbers[i] > 256){
        return false;
      }
    }
    return true;
  }
}
