export interface Nvr{
  id: string;
  description: string;
  ip: string;
  channels: number;
  port: number;
  rtspPort: number;
  username: string;
  password: string;
}
