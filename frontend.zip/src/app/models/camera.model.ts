export interface CameraModel{
  id: string;
  NvrId: string;
  name: string;
  channel: number;
  ip: string;
  index: number;
}
